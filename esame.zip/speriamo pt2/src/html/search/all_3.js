var searchData=
[
  ['utente',['utente',['../structutente.html',1,'']]]
];
