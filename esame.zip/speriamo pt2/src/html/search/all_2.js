var searchData=
[
  ['preferenza',['preferenza',['../structpreferenza.html',1,'']]]
];
