var searchData=
[
  ['artista',['artista',['../structartista.html',1,'']]]
];
