/*
 * function.h
 *
 *  Created on: 23 giu 2018
 *      Author: f99
 */

/**
 * @file    function.h
 * @author  Dimiccoli Davide & Fuccilli Francesco
 * @version 1.0
 */

#ifndef FUNCTION_H
#define FUNCTION_H






#include <stdbool.h>
//#include <function.c>


/**
 * Questa funzione controlla se il nome e la password sono corretti e presenti nel file user.csv
 * @param[in] nome Il nome dell'utente
 * @param[in] password La password dell'utente
 * @return Ritorna la struct utente se esiste altrimenti una struttura con il campo id impostato
 * a "-1"
 */
struct utente autenticazione(char *nome,char *password);
struct utente input_registrazione();
bool registrazione(struct utente utente);
//bool aggiungi_artista(struct artista artista);
bool controllo_funzioni(bool app,char tipologia);
bool visualizza_elenco(char tipologia,char *txt);
char * visualizza_dati_id(int id, char *txt,char tipologia,char* string);
struct artista string_to_struct_artista(char *string);
struct utente string_to_struct_utente(char *string);
struct artista modifica_dati_struct(struct artista to_modify);
struct utente modifica_dati_struct_utente(struct utente to_modify);
bool modifica_file_artisti(struct artista modificato,char tipologia);
bool modifica_file_utenti(struct utente modificato,char tipologia,char tipologia2);
void stampa_struct_artista(struct artista to_print);
void stampa_struct_utente(struct utente to_print);
bool ricerca_artisti(char *string,char tipo,int id_utente);
int algoritmo_ricerca(char *text,char *pattern);
int controllo_nome(char *txt,char *nome);
//bool controllo_data_nascita(struct data b_day);
bool inserimento_ascolti_e_preferenze(int id_artista,int id_utente,char tipologia);
bool controllo_file_preferenze(char * string);
bool ordinamento_artisti(char tipologia,int id_utente);
char controllo_risposta(char risposta[20],char tipologia);
bool ascolti_or_preferenze(int id_utente,int id_artista,char *nome_artista);
char* to_minuscolo(char *string);
struct preferenza string_to_struct_preferenza(char *string);
bool preferenze_e_ascolti_utente(int id_utente,char *tipo);
bool elimina_preferenze(int id,char tipologia);
bool modifica_preferenza(int id_artista,int id_utente,char tipologia);
bool alfanumerico(char *string);

#endif /* FUNCTION_H_ */
